module.exports = {
  BOT_TOKEN: "8319669478:AAEcdgefg8_dBTkQNlq1uoWyIXEyUhBBFZQ",
};
